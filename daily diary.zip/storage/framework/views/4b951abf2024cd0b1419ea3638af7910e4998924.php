<?php
use App\Models\Expense;
?>

<?php $__env->startSection('title', 'Expense'); ?>
<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('style'); ?>
        <style>
            .dropLink {
                display: block !important;
                padding: 0.5rem 4rem !important;
            }

            .mainDiv {
                position: absolute;
            }

            .footer {
                position: sticky;
                bottom: 0;
                text-align: center;
                padding: 10px;
                background-color: antiquewhite
            }

            .form-control:focus {
                color: #495057 !important;
                background-color: #fff !important;
                border-color: #80bdff !important;
                outline: 0 !important;
            }
            #filterForm{
                display: none;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#"> <img src="<?php echo e(asset('assets/images/icons/favicon.png')); ?>" width="30"
                height="30" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('user.home')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('user.expense')); ?>">Get Expense <span
                            class="sr-only">(current)</span></a>
                </li>


            </ul>
            <ul class="my-2 my-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropLink dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo e(auth()->user()->name); ?>

                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid mainDiv mt-4">
        <?php if(session()->get('success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e(session()->get('success')); ?></strong>
            </div>
        <?php endif; ?>

        <div class="card">

            <div class="card-header">
                <a href="#" class="btn btn-warning" id="filter"><i class="fa fa-search"></i> Filter Expense</a>

                <div id="filterForm" class="mt-2">
                    <form action="<?php echo e(route('user.filterExpense')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-sm-5 col-md-5 col-lg-5">
                                <div class="form-group">
                                    <label for="">Expense Start Date</label>
                                    <input type="date" name="expense_start_date" class="form-control"
                                        placeholder="Expense Start Date" required>
                                </div>
                            </div>

                            <div class="col-sm-5 col-md-5 col-lg-5">
                                <div class="form-group">
                                    <label for="">Expense End Date</label>
                                    <input type="date" name="expense_end_date" class="form-control"
                                        placeholder="Expense Description" required>
                                </div>
                            </div>

                            <div class="col-sm-2 col-md-2 col-lg-2">
                                <div class="btn w-100">
                                    <button type="submit" class="btn btn-success"><i class="fa fa-search"></i></button>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>

            </div>
            <div class="card-body">
<h4 class="text-center text-success mb-4">Dear, <b><?php echo e(auth()->user()->name); ?></b>! Your Total Expense Report.</h4>
                <div class="table-responsive">
                    <table class="display table table-bordered table-hover text-center" id="myTab" style="width: 100%">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Desc.</th>
                                <th>Expense</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <?php
                                $expenseData = Expense::where('user_id', auth()->user()->id)
                                    ->where('date', $expense->date)
                                    ->orderBy('date', 'asc')
                                    ->get();
                                $expenseCount = Expense::where('user_id', auth()->user()->id)
                                    ->where('date', $expense->date)
                                    ->count();
                                ?>

                                <tr>
                                    <td rowspan="<?php echo e($expenseCount + 1); ?>" align="center" style="vertical-align: middle;">
                                        <?php echo e(\Carbon\Carbon::parse($expense->date)->format('d M Y')); ?></td>

                                </tr>
                                <?php $__currentLoopData = $expenseData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($data->expense_desc); ?></td>
                                        <td>&#8377; <?php echo e($data->expense); ?>.00</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h3 class="text-center">No Data Found.</h3>
                            <?php endif; ?>
                            <tr>
                                <td colspan="2" class="text-right"><b>Total Expense</b></td>
                                <td><b>&#8377; <?php echo e($expenseSum); ?>.00</b></td>
                            </tr>
                            <tr>
                                <td colspan="3" class="text-right"><a href="#" onclick="window.print()"
                                        class="btn btn-primary"><i class="fa fa-download"></i> Download</a></td>

                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="footer mt-4">
            <div class="foot">
                <h6>&copy; 2022 - <?= date('Y') ?> <a href="#">Vicky Digital Solutions</a></h6>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('#filter').on('click',function(){
                $('#filterForm').toggle();
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/daily-diary-app/resources/views/getExpense.blade.php ENDPATH**/ ?>